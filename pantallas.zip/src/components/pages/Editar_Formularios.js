import React from 'react';

const Editar_Formularios = () => {
  return (
    <div>
      <h2>Pantalla de Editar</h2>
    </div>
  );
}

export default Editar_Formularios;